#include <STC15F2K60S2.H>
#include "onewire.h"
#include "iic.h"
unsigned char shumaguanduanma[17] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71,0x00};//16 mie
unsigned char shumaguan[8] = {16,16,16,16, 16,16,16,16};
int n = 0;
unsigned int display_time = 0;
unsigned int adc_dat = 0,adc_time = 0;

void else_init()
{
	P0 = 0x00; P2&=0x1f; P2|=0xa0; P0 = 0x00; P2&=0x1f; P0 = 0x00;	
	P0 = 0XFF; P2&=0x1f; P2|=0x80; P0 = 0xff; P2&=0x1f; P0 = 0XFF;	
}

void Timer0Init(void)		//1??@12.000MHz
{
	AUXR |= 0x80;		//?????1T??
	TMOD &= 0xF0;		//???????
	TL0 = 0x20;		//??????
	TH0 = 0xD1;		//??????
	TF0 = 0;		//??TF0??
	TR0 = 1;		//???0????
	ET0 = 1;
	EA = 1;
}

void iic_adc(unsigned char addr)
{
	EA = 0;
	I2CStart();
	I2CSendByte(0x90);
	I2CWaitAck();
	I2CSendByte(addr);
	I2CWaitAck();
	I2CStart();
	I2CSendByte(0x91);
	I2CWaitAck();
	adc_dat = I2CReceiveByte();
	I2CWaitAck();
	I2CStop();
	adc_dat = adc_dat*1.9;//turn 100
	EA = 1;
}


void display()
{
	P0 = 0XFF; P2&=0x1f; P2|=0XE0; P0 = ~shumaguanduanma[shumaguan[n]];  P2&=0x1f; P0 = 0XFF;	//DUAN
	P0 = 0XFF; P2&=0x1f; P2|=0XC0; P0 = 0x01<<n; P2&=0x1f; P0 = 0XFF; //WEI
	n++;
	if(n>7)n=0;
}

void main()
{
	else_init();
	Timer0Init();	
	while(1)
	{
		if(adc_time>=2000)
		{
			iic_adc(0x01);
			shumaguan[0] = adc_dat%10000/1000;
			shumaguan[1] = adc_dat%1000/100;
			shumaguan[2] = adc_dat%100/10;
			shumaguan[3] = adc_dat%10;
			adc_time = 0;
		}
	}
}

void timer0() interrupt 1
{
	display_time++;
	if(display_time>=2)
	{
		display();
		display_time = 0;
	}
	adc_time++;
}


