#ifndef __IIC_H_
#define __IIC_H_
void I2CSendAck(unsigned char ackbit);
unsigned char I2CWaitAck(void);
void I2CStart(void);
void I2CStop(void);
unsigned char I2CReceiveByte(void);
void I2CSendByte(unsigned char byt);
#endif